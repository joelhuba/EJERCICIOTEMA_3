public class Main {

    public static void main(String[] arg) {
        coche micoche=new coche();
        micoche.aumentarpuertas();
        System.out.println(micoche.puertas);

       int resultado;
       resultado= suma(20,50,60);
        System.out.println(resultado);

    }


        public static int suma(int a, int b,int c) {
            return a+b+c;
            

        }
}

class coche{
    public int puertas=4;

    public void aumentarpuertas(){
        this.puertas++;

    }

}



